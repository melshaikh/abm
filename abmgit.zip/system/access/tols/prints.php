<?php
function printFooter(){
    echo '<footer class="footer text-center">
                All Rights Reserved by ABM UTARA. Designed and Developed by
                <a href="#">Mohamed Elshaikh</a>.
            </footer>';
}