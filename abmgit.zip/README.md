# Bootstrap-Template
Responsive one page template for croogo on twitter bootstrap 

Creator

Created by and is maintained by Hardeep Singh,

    https://github.com/hardy091

Bugs

Have a bug or an issue with this theme? Open a new issue.
